# Super Mario Bros With SFML in C#
This project was really intended to develop a game engine for 2d plaformers.  In doing so, it took shape of Super Mario Bros.  


This is my attempt at remaking the famous SMB game for the Nintendo 8-bit.  Consider it a demo right now, as it is VERY incomplete.  But the engine is developing. Hopefully it may help someone else develop a 2d platform game.  It utilizes SFML.

Id love to see this a complete game, so if you are interested in working on it, please feel free to jump in.

Note:  I am not a professional game developer!  Just a hobby project.

Cursor keys to move, space bar jumps.  Requires .NET 4.5 framework

**Updates**

1/31/15
* Scoring
* Player lives counter
* Game over screen
* Minor fixes

1/25/15
* Coinbox animations
* Improved collision detection
* Flag pole animation
* Code cleanup & bug fixes

1/22/15
* Animation effects for static entities
* Additional sound effects
* Latest versions of SFML for more accurate clock control
* Still some collision detection issues

1/18/15
* Start screen added
* Others have brought to my attention the lag / slowdon depending on the machine. Working on correcting the game time issue which will resolve.  Thanks!
* Mario can now stomp enemies
* KoopaTroopas added

![](Home_Capture1.png)